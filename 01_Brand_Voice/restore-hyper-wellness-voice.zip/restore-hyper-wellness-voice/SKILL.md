---
name: restore-hyper-wellness-voice
version: 1.0.0
description: |
  Write in Restore Hyper Wellness's brand voice for any content type. Use when writing
  ad copy, social posts, website copy, email, landing pages, video scripts, or any
  marketing content for Restore Hyper Wellness or any individual Restore studio.
  Triggers on: 'Restore', 'Restore Hyper Wellness', 'restore copy', 'restore ad',
  'restore social', 'restore email', 'restore post', 'write for restore', 'restore
  voice', 'restore brand', 'restore script', 'restore landing page', 'restore studio'.
---

# Restore Hyper Wellness Voice

Restore Hyper Wellness is a personalized, science-backed health and performance brand offering therapies like Cryotherapy, Red Light Therapy, Infrared Sauna, Compression, IV Drip Therapy, and Skin Health services. The voice is a calm clinician's authority paired with the warmth of a trusted advisor — credible enough to trust with your health, human enough to want around.

## The one-sentence rule

Write like a clinician who's also a friend.

## Core voice

1. **Clear and concise.** Plain language, never jargon. Translate clinical into felt benefit.
2. **Conversational, never clinical.** Talk to the client, not at them.
3. **Science-backed but warm.** Cite the mechanism briefly, then the benefit.
4. **Active voice always.** "Cryotherapy may help reduce inflammation" — not "inflammation may be reduced by..."
5. **Aspirational, never prescriptive.** "May help you" is the signature lead-in. Never promise. Always invite.

## Non-negotiables (every piece)

- **Tagline, exact format:** "Fuel Your Body. Feel the Results."
- **Benefit lead-in, exact format:** "{Therapy} may help to..." — every benefit claim leads with this. Never "Cryotherapy reduces pain." Always "Cryotherapy may help to reduce pain."
- **Use:** therapies, clients, studios, nutrients, Members, Membership, certified Nurses
- **Never:** modalities, customers, stores, ingredients, patients, participants
- **Capitalize:** Clients, Membership, Members, Cryotherapy, Red Light Therapy, Infrared Sauna, Compression, IV Drip Therapy, IV Drips, Drips, Mild Hyperbaric Oxygen Therapy (always include "Mild"), NAD+ IV, Niagen (NR) IV, GLP-1 Plans, Hydrafacial™
- **No Oxford commas.** Every list of three+ items: drop the comma before the final "and"/"or". "Hydrate, replenish and recover" — not "Hydrate, replenish, and recover". Multi-word list items count too.
- **Active voice always.** "Our certified Nurses administer every Drip."
- **AP Style.** Numerals for time, ages, percentages, dates, money. Hyphenate compound modifiers before nouns. No hyphens after -ly adverbs.
- **Em dashes —** no spaces on either side. Maximum 1–2 per piece.
- **No semicolons.** Use periods or em dashes.
- **Exclamation points: 1 max per piece.** Never `!!`.
- **Title Case for marketing headlines.** Capitalize prepositions of 4+ letters (With, From, Over, Into, Between). Lowercase shorter prepositions (of, to, in, on) unless first or last.
- **Trademarks intact.** Hydrafacial™, Neveskin™, NormaTec on first mention.
- **Every claim earns proof.** A stat, a Member testimonial, a clinical reference, or a concrete therapy mechanism. No vague hype without grounding.

## Channel cheat-sheet

| Channel | Top rule |
|---|---|
| **Website** | Lead with benefit. Pair every claim with proof or "may help to..." Cream surfaces for warmer blocks. |
| **Instagram** | Aspirational, lifestyle-forward. Title Case captions. 0–2 emojis. |
| **Facebook** | Story-driven. Member testimonials. Longer-form OK. CTA + studio locator. |
| **TikTok** | Hook in 2 seconds. Educational or transformation. Lifestyle, never clinical. |
| **Email** | Clear-benefit subject line. Body in Open Sans. Signature: Nurse or Studio Manager. |
| **Paid Ads** | Compliance-first. Meta safe zones. No needles. Nurses in gloves. Problem/solution, never side-by-side before/after. |
| **In-Studio** | Higher density OK. Service descriptions can run longer. Disclaimer included. |
| **B2B / Franchise** | Operational, not aspirational. Member metrics, retention, AUV. |

For deeper channel guidance (ad compliance, hashtag conventions, scenario templates), load `references/channels.md`.

## Generation protocol

1. **Identify therapy + audience.** Skin Health, athletic recovery, longevity, proactive wellness?
2. **Lead with the benefit, not the brand.** What does this client get?
3. **Use "may help to..."** for every claim. No exceptions.
4. **Active voice, contractions where appropriate.** "You'll feel" in social/email; full-word in clinical descriptions.
5. **Run the editing protocol** (load `references/editing.md`).

## When to load references

- **`references/editing.md`** — every final edit pass + when revising existing copy.
- **`references/examples.md`** — when output sounds generic or you want pattern matching.
- **`references/channels.md`** — when prompt names a channel and you need ad compliance specifics, hashtag sets, scenario templates.
- **`references/vocabulary.md`** — for therapy-specific approved claims, brand stats, full forbidden/preferred terminology.

The canonical source is `../Restore_Brand_Voice_Guide.md`. If anything here conflicts with the guide, the guide wins.
